﻿namespace MushiKen_Kicode
{
    partial class frmMushi
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMushi));
            this.cmdRegleDuJeu = new System.Windows.Forms.Button();
            this.picAvatar03 = new System.Windows.Forms.PictureBox();
            this.picAvatar02 = new System.Windows.Forms.PictureBox();
            this.picAvatar01 = new System.Windows.Forms.PictureBox();
            this.cmdQuitter = new System.Windows.Forms.Button();
            this.cmdJouer = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPseudo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar01)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdRegleDuJeu
            // 
            this.cmdRegleDuJeu.BackColor = System.Drawing.Color.MistyRose;
            this.cmdRegleDuJeu.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdRegleDuJeu.Location = new System.Drawing.Point(274, 503);
            this.cmdRegleDuJeu.Name = "cmdRegleDuJeu";
            this.cmdRegleDuJeu.Size = new System.Drawing.Size(186, 64);
            this.cmdRegleDuJeu.TabIndex = 23;
            this.cmdRegleDuJeu.Text = "Règles du jeu";
            this.cmdRegleDuJeu.UseVisualStyleBackColor = false;
            this.cmdRegleDuJeu.Click += new System.EventHandler(this.cmdRegleDuJeu_Click);
            // 
            // picAvatar03
            // 
            this.picAvatar03.BackColor = System.Drawing.Color.Transparent;
            this.picAvatar03.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.avatar_03;
            this.picAvatar03.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picAvatar03.Cursor = System.Windows.Forms.Cursors.Default;
            this.picAvatar03.Location = new System.Drawing.Point(477, 332);
            this.picAvatar03.Name = "picAvatar03";
            this.picAvatar03.Size = new System.Drawing.Size(100, 100);
            this.picAvatar03.TabIndex = 22;
            this.picAvatar03.TabStop = false;
            this.picAvatar03.Click += new System.EventHandler(this.picAvatar03_Click);
            // 
            // picAvatar02
            // 
            this.picAvatar02.BackColor = System.Drawing.Color.Transparent;
            this.picAvatar02.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.avatar_02;
            this.picAvatar02.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picAvatar02.Location = new System.Drawing.Point(311, 332);
            this.picAvatar02.Name = "picAvatar02";
            this.picAvatar02.Size = new System.Drawing.Size(100, 100);
            this.picAvatar02.TabIndex = 21;
            this.picAvatar02.TabStop = false;
            this.picAvatar02.Click += new System.EventHandler(this.picAvatar02_Click);
            // 
            // picAvatar01
            // 
            this.picAvatar01.BackColor = System.Drawing.Color.Transparent;
            this.picAvatar01.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.avatar_01;
            this.picAvatar01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picAvatar01.Location = new System.Drawing.Point(125, 332);
            this.picAvatar01.Name = "picAvatar01";
            this.picAvatar01.Size = new System.Drawing.Size(100, 100);
            this.picAvatar01.TabIndex = 20;
            this.picAvatar01.TabStop = false;
            this.picAvatar01.Click += new System.EventHandler(this.picAvatar01_Click);
            // 
            // cmdQuitter
            // 
            this.cmdQuitter.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdQuitter.ForeColor = System.Drawing.Color.Red;
            this.cmdQuitter.Location = new System.Drawing.Point(557, 529);
            this.cmdQuitter.Name = "cmdQuitter";
            this.cmdQuitter.Size = new System.Drawing.Size(107, 38);
            this.cmdQuitter.TabIndex = 19;
            this.cmdQuitter.Text = "Quitter";
            this.cmdQuitter.UseVisualStyleBackColor = true;
            this.cmdQuitter.Click += new System.EventHandler(this.cmdQuitter_Click);
            // 
            // cmdJouer
            // 
            this.cmdJouer.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdJouer.Location = new System.Drawing.Point(93, 529);
            this.cmdJouer.Name = "cmdJouer";
            this.cmdJouer.Size = new System.Drawing.Size(107, 38);
            this.cmdJouer.TabIndex = 18;
            this.cmdJouer.Text = "Jouer";
            this.cmdJouer.UseVisualStyleBackColor = true;
            this.cmdJouer.Click += new System.EventHandler(this.cmdJouer_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(68, 274);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(242, 25);
            this.label3.TabIndex = 17;
            this.label3.Text = "Quelle image préfères-tu ?";
            // 
            // txtPseudo
            // 
            this.txtPseudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPseudo.Location = new System.Drawing.Point(73, 187);
            this.txtPseudo.Name = "txtPseudo";
            this.txtPseudo.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtPseudo.Size = new System.Drawing.Size(237, 30);
            this.txtPseudo.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 25);
            this.label2.TabIndex = 15;
            this.label2.Text = "Quel est ton pseudo :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(238, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 45);
            this.label1.TabIndex = 14;
            this.label1.Text = "Le Mushi Ken";
            // 
            // frmMushi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.fondJApon_Filigrane;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(732, 593);
            this.Controls.Add(this.cmdRegleDuJeu);
            this.Controls.Add(this.picAvatar03);
            this.Controls.Add(this.picAvatar02);
            this.Controls.Add(this.picAvatar01);
            this.Controls.Add(this.cmdQuitter);
            this.Controls.Add(this.cmdJouer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPseudo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMushi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Welcome";
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar01)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdRegleDuJeu;
        private System.Windows.Forms.PictureBox picAvatar03;
        private System.Windows.Forms.PictureBox picAvatar02;
        private System.Windows.Forms.PictureBox picAvatar01;
        private System.Windows.Forms.Button cmdQuitter;
        private System.Windows.Forms.Button cmdJouer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPseudo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

