﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MushiKen_Kicode
{
    public partial class frmMushi : Form
    {
        #region Variable

        string pseudo = "";
        Image image;
        frm_Zone_Jeu fenetre;
        frm_Regle regleDuJeu;
        bool avatar = false;

        #endregion

        public frmMushi()
        {
            InitializeComponent();
        }
        private void borderAvatar(PictureBox uneImage)
        {
            picAvatar01.BorderStyle = BorderStyle.None;
            picAvatar02.BorderStyle = BorderStyle.None;
            picAvatar03.BorderStyle = BorderStyle.None;
            uneImage.BorderStyle = BorderStyle.Fixed3D;
            image = uneImage.BackgroundImage;
            avatar = true;
        }

        #region Click

        private void picAvatar01_Click(object sender, EventArgs e)
        {
            borderAvatar(picAvatar01);
        }

        private void picAvatar02_Click(object sender, EventArgs e)
        {
            borderAvatar(picAvatar02);
        }

        private void picAvatar03_Click(object sender, EventArgs e)
        {
            borderAvatar(picAvatar03);
        }

        private void cmdQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdJouer_Click(object sender, EventArgs e)
        {
            pseudo = txtPseudo.Text;
            if (pseudo != "" && avatar == true)
            {
                fenetre = new frm_Zone_Jeu(pseudo, image);
                fenetre.ShowDialog();
            }
            else
            {
                Console.WriteLine(image);
                MessageBox.Show(
                    "Il manque des informations",
                    "Erreur",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error,
                    MessageBoxDefaultButton.Button1);
            }
        }

        private void cmdRegleDuJeu_Click(object sender, EventArgs e)
        {
            regleDuJeu = new frm_Regle();
            regleDuJeu.ShowDialog();
        }
        #endregion
    }
}
