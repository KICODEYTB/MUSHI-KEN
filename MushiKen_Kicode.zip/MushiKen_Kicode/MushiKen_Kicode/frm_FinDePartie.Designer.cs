﻿namespace MushiKen_Kicode
{
    partial class frm_FinDePartie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_FinDePartie));
            this.picResultat = new System.Windows.Forms.PictureBox();
            this.cmdRejouer = new System.Windows.Forms.Button();
            this.cmdQuitter = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picResultat)).BeginInit();
            this.SuspendLayout();
            // 
            // picResultat
            // 
            this.picResultat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picResultat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picResultat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picResultat.ErrorImage = null;
            this.picResultat.Location = new System.Drawing.Point(0, 0);
            this.picResultat.Name = "picResultat";
            this.picResultat.Size = new System.Drawing.Size(492, 391);
            this.picResultat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picResultat.TabIndex = 1;
            this.picResultat.TabStop = false;
            // 
            // cmdRejouer
            // 
            this.cmdRejouer.BackColor = System.Drawing.Color.Gold;
            this.cmdRejouer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdRejouer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cmdRejouer.Location = new System.Drawing.Point(0, 336);
            this.cmdRejouer.Name = "cmdRejouer";
            this.cmdRejouer.Size = new System.Drawing.Size(113, 55);
            this.cmdRejouer.TabIndex = 4;
            this.cmdRejouer.Text = "Rejouer";
            this.cmdRejouer.UseVisualStyleBackColor = false;
            this.cmdRejouer.Click += new System.EventHandler(this.cmdRejouer_Click);
            // 
            // cmdQuitter
            // 
            this.cmdQuitter.BackColor = System.Drawing.Color.Red;
            this.cmdQuitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdQuitter.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdQuitter.Location = new System.Drawing.Point(374, 336);
            this.cmdQuitter.Name = "cmdQuitter";
            this.cmdQuitter.Size = new System.Drawing.Size(118, 55);
            this.cmdQuitter.TabIndex = 5;
            this.cmdQuitter.Text = "Quitter";
            this.cmdQuitter.UseVisualStyleBackColor = false;
            this.cmdQuitter.Click += new System.EventHandler(this.cmdQuitter_Click);
            // 
            // lblResult
            // 
            this.lblResult.BackColor = System.Drawing.Color.Transparent;
            this.lblResult.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(0, 0);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(492, 48);
            this.lblResult.TabIndex = 6;
            this.lblResult.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // frm_FinDePartie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 391);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.cmdQuitter);
            this.Controls.Add(this.cmdRejouer);
            this.Controls.Add(this.picResultat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_FinDePartie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Finish ?";
            this.Click += new System.EventHandler(this.cmdQuitter_Click);
            ((System.ComponentModel.ISupportInitialize)(this.picResultat)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picResultat;
        private System.Windows.Forms.Button cmdRejouer;
        private System.Windows.Forms.Button cmdQuitter;
        private System.Windows.Forms.Label lblResult;
    }
}