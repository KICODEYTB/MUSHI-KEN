﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace MushiKen_Kicode
{
    public partial class frm_FinDePartie : Form
    {
        #region Variable

        SoundPlayer player;
        #endregion

        public frm_FinDePartie(String result, String vainqueur)
        {
            InitializeComponent();
            sound(result, vainqueur);
        }

        /// <summary>
        /// Procédure => affichage du gif et démarrage du son en fonction du gagnant
        /// </summary>
        /// <param name="result">la personne qui a gagner entre le joueur ou l'ordinateur</param>
        /// <param name="vainqueur">Le nom du gagant</param>
        private void sound(String result, String vainqueur)
        {
            if (result == "Joueur")
            {
                picResultat.Image = Properties.Resources.victoireJoueur;
                player = new SoundPlayer(Properties.Resources.Tesla_Jingle);
            }
            else
            {
                picResultat.Image = Properties.Resources.victoireOrdinateur;
                player = new SoundPlayer(Properties.Resources.j_perdu2);
            }

            lblResult.Text = "\t" + vainqueur + " a gagné";
            player.Play();
        }

        #region Click

        private void cmdQuitter_Click(object sender, EventArgs e)
        {
            player.Stop();
            Application.Exit();
        }

        private void cmdRejouer_Click(object sender, EventArgs e)
        {
            player.Stop();
            this.Close();
        }
        #endregion
    }
}
