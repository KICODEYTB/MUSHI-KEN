﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MushiKen_Kicode
{
    public partial class frm_Regle : Form
    {
        #region Variable

        List<Image> image;
        List<String> texteImage;
        List<String> titreTexte;
        List<Button> buttonList;

        #endregion

        public frm_Regle()
        {
            InitializeComponent();
            initialisation();
        }

        #region Methode

        /// <summary>
        /// Initialisation des propriétés
        /// </summary>
        private void initialisation()
        {
            buttonList = new List<Button>() { button1, button2, button3, button4, button5 };
            image = new List<Image>()
            {
                Properties.Resources.debutDuJeu,
                Properties.Resources.zoneDeJeu,
                Properties.Resources.regleDuJeu,
                Properties.Resources.timer,
                Properties.Resources.bonneChance
            };
            texteImage = new List<string>()
            {
                "Pour commencer, vous devez entrer votre prénom et sélectionnez votre image préféré pour débuter une partie",
                "Sur cette interface, un joueur et un ordinateur choisissent simulténament un des animaux\nVous => les images du haut\nOrdinateur => image du bas",
                "Chaque coup est comparé pour trouver le gagnant \nAinsi :\nGrenouille > Limace\nLimace > Serpent\nSerpent > Grenouille",
                "Si vous ne cliquez pas sur une image au bout de 30 sec, le jeu considère que vous avez perdu",
                "Je vous laisse découvrir ce jeu😎"
            };
            titreTexte = new List<string>()
            {
                "Bienvenue à toi",
                "Le Moshi-Ken",
                "Mode Du Jeu",
                "Timer",
                "Bonne chance"
            };
            picImageRegleDuJeu.Image = image[0];
            lblResult.Text = texteImage[0];
            lblTitreImage.Text = titreTexte[0];
            button1.Enabled = false;
        }
        /// <summary>
        /// Initialisation des Button
        /// </summary>
        /// <param name="button">List des Button</param>
        private void initialiseButton(List<Button> button)
        {
            for (int i = 0; i < button.Count; i++)
            {
                button[i].Enabled = true;
                button[i].BackColor = Color.WhiteSmoke;
            }
        }

        /// <summary>
        /// Procédure => Affichage des règles du jeu
        /// </summary>
        /// <param name="tag">Tag des Button</param>
        private void affichageRegleDuJeu(int tag)
        {
            progressBar.Value = (tag * 100) / 5;
            picImageRegleDuJeu.Image = image[tag - 1];
            lblResult.Text = texteImage[tag - 1];
            lblTitreImage.Text = titreTexte[tag - 1];
            cmdQuitter.Visible = false;
        }

        /// <summary>
        /// Procédure => Cliquer sur un des Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonScrollImage_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            int tagButton = int.Parse(button.Tag.ToString());

            initialiseButton(buttonList);

            button.Enabled = false;
            button.BackColor = Color.Gold;

            affichageRegleDuJeu(tagButton);

            if (tagButton == 5)
            {
                cmdQuitter.Visible = true;
            }
        }

        /// <summary>
        /// Quitter l'application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #endregion

        #region Click

        private void cmdQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
