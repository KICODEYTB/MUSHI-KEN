﻿namespace MushiKen_Kicode
{
    partial class frm_Zone_Jeu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Zone_Jeu));
            this.panelTimer = new System.Windows.Forms.Panel();
            this.lblTemps0 = new System.Windows.Forms.Label();
            this.lblTempsRestantTitre = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblPseudoJeu = new System.Windows.Forms.Label();
            this.picOrdinateurSerpent = new System.Windows.Forms.PictureBox();
            this.picOrdinateurLimace = new System.Windows.Forms.PictureBox();
            this.picOrdinateurGrenouille = new System.Windows.Forms.PictureBox();
            this.picJoueurSerpent = new System.Windows.Forms.PictureBox();
            this.picJoueurLimace = new System.Windows.Forms.PictureBox();
            this.picJoueurGrenouille = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblGagner = new System.Windows.Forms.Label();
            this.cmdQuitter_Jeu = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPseudo = new System.Windows.Forms.Label();
            this.picImageJoueur = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelTimer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picOrdinateurSerpent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOrdinateurLimace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOrdinateurGrenouille)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picJoueurSerpent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picJoueurLimace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picJoueurGrenouille)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picImageJoueur)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTimer
            // 
            this.panelTimer.BackColor = System.Drawing.Color.MintCream;
            this.panelTimer.Controls.Add(this.lblTemps0);
            this.panelTimer.Controls.Add(this.lblTempsRestantTitre);
            this.panelTimer.Controls.Add(this.lblTimer);
            this.panelTimer.Location = new System.Drawing.Point(851, 96);
            this.panelTimer.Name = "panelTimer";
            this.panelTimer.Size = new System.Drawing.Size(159, 82);
            this.panelTimer.TabIndex = 32;
            // 
            // lblTemps0
            // 
            this.lblTemps0.AutoSize = true;
            this.lblTemps0.BackColor = System.Drawing.Color.Transparent;
            this.lblTemps0.Font = new System.Drawing.Font("Rockwell Nova", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemps0.Location = new System.Drawing.Point(22, 32);
            this.lblTemps0.Name = "lblTemps0";
            this.lblTemps0.Size = new System.Drawing.Size(63, 47);
            this.lblTemps0.TabIndex = 16;
            this.lblTemps0.Text = "0 :";
            // 
            // lblTempsRestantTitre
            // 
            this.lblTempsRestantTitre.AutoSize = true;
            this.lblTempsRestantTitre.BackColor = System.Drawing.Color.Transparent;
            this.lblTempsRestantTitre.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempsRestantTitre.Location = new System.Drawing.Point(21, 13);
            this.lblTempsRestantTitre.Name = "lblTempsRestantTitre";
            this.lblTempsRestantTitre.Size = new System.Drawing.Size(103, 18);
            this.lblTempsRestantTitre.TabIndex = 15;
            this.lblTempsRestantTitre.Text = "Temps Restant :";
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.BackColor = System.Drawing.Color.Transparent;
            this.lblTimer.Font = new System.Drawing.Font("Rockwell Nova", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.Location = new System.Drawing.Point(79, 32);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(62, 47);
            this.lblTimer.TabIndex = 14;
            this.lblTimer.Text = "30";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(847, 509);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 27);
            this.label6.TabIndex = 31;
            this.label6.Text = "Ordinateur";
            // 
            // lblPseudoJeu
            // 
            this.lblPseudoJeu.AutoSize = true;
            this.lblPseudoJeu.BackColor = System.Drawing.Color.Transparent;
            this.lblPseudoJeu.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPseudoJeu.Location = new System.Drawing.Point(847, 344);
            this.lblPseudoJeu.Name = "lblPseudoJeu";
            this.lblPseudoJeu.Size = new System.Drawing.Size(72, 27);
            this.lblPseudoJeu.TabIndex = 30;
            this.lblPseudoJeu.Text = "Pseudo";
            // 
            // picOrdinateurSerpent
            // 
            this.picOrdinateurSerpent.BackColor = System.Drawing.Color.Snow;
            this.picOrdinateurSerpent.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.serpent_bleu;
            this.picOrdinateurSerpent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picOrdinateurSerpent.Enabled = false;
            this.picOrdinateurSerpent.Location = new System.Drawing.Point(615, 452);
            this.picOrdinateurSerpent.Name = "picOrdinateurSerpent";
            this.picOrdinateurSerpent.Size = new System.Drawing.Size(130, 130);
            this.picOrdinateurSerpent.TabIndex = 29;
            this.picOrdinateurSerpent.TabStop = false;
            this.picOrdinateurSerpent.Tag = "serpent";
            this.picOrdinateurSerpent.Click += new System.EventHandler(this.picture_Click);
            // 
            // picOrdinateurLimace
            // 
            this.picOrdinateurLimace.BackColor = System.Drawing.Color.Snow;
            this.picOrdinateurLimace.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.limace_bleu;
            this.picOrdinateurLimace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picOrdinateurLimace.Enabled = false;
            this.picOrdinateurLimace.Location = new System.Drawing.Point(416, 452);
            this.picOrdinateurLimace.Name = "picOrdinateurLimace";
            this.picOrdinateurLimace.Size = new System.Drawing.Size(130, 130);
            this.picOrdinateurLimace.TabIndex = 28;
            this.picOrdinateurLimace.TabStop = false;
            this.picOrdinateurLimace.Tag = "limace";
            this.picOrdinateurLimace.Click += new System.EventHandler(this.picture_Click);
            // 
            // picOrdinateurGrenouille
            // 
            this.picOrdinateurGrenouille.BackColor = System.Drawing.Color.Snow;
            this.picOrdinateurGrenouille.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.grenouille_bleu;
            this.picOrdinateurGrenouille.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picOrdinateurGrenouille.Enabled = false;
            this.picOrdinateurGrenouille.Location = new System.Drawing.Point(236, 452);
            this.picOrdinateurGrenouille.Name = "picOrdinateurGrenouille";
            this.picOrdinateurGrenouille.Size = new System.Drawing.Size(130, 130);
            this.picOrdinateurGrenouille.TabIndex = 27;
            this.picOrdinateurGrenouille.TabStop = false;
            this.picOrdinateurGrenouille.Tag = "grenouille";
            this.picOrdinateurGrenouille.Click += new System.EventHandler(this.picture_Click);
            // 
            // picJoueurSerpent
            // 
            this.picJoueurSerpent.BackColor = System.Drawing.Color.Snow;
            this.picJoueurSerpent.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.serpent_vert;
            this.picJoueurSerpent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picJoueurSerpent.Location = new System.Drawing.Point(615, 283);
            this.picJoueurSerpent.Name = "picJoueurSerpent";
            this.picJoueurSerpent.Size = new System.Drawing.Size(130, 130);
            this.picJoueurSerpent.TabIndex = 26;
            this.picJoueurSerpent.TabStop = false;
            this.picJoueurSerpent.Tag = "serpent";
            this.picJoueurSerpent.Click += new System.EventHandler(this.picture_Click);
            // 
            // picJoueurLimace
            // 
            this.picJoueurLimace.BackColor = System.Drawing.Color.Snow;
            this.picJoueurLimace.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.limace_verte;
            this.picJoueurLimace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picJoueurLimace.Location = new System.Drawing.Point(416, 283);
            this.picJoueurLimace.Name = "picJoueurLimace";
            this.picJoueurLimace.Size = new System.Drawing.Size(130, 130);
            this.picJoueurLimace.TabIndex = 25;
            this.picJoueurLimace.TabStop = false;
            this.picJoueurLimace.Tag = "limace";
            this.picJoueurLimace.Click += new System.EventHandler(this.picture_Click);
            // 
            // picJoueurGrenouille
            // 
            this.picJoueurGrenouille.BackColor = System.Drawing.Color.Snow;
            this.picJoueurGrenouille.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.grenouille_verte1;
            this.picJoueurGrenouille.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picJoueurGrenouille.Location = new System.Drawing.Point(236, 283);
            this.picJoueurGrenouille.Name = "picJoueurGrenouille";
            this.picJoueurGrenouille.Size = new System.Drawing.Size(130, 130);
            this.picJoueurGrenouille.TabIndex = 24;
            this.picJoueurGrenouille.TabStop = false;
            this.picJoueurGrenouille.Tag = "grenouille";
            this.picJoueurGrenouille.Click += new System.EventHandler(this.picture_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Snow;
            this.panel1.Controls.Add(this.lblScore);
            this.panel1.Controls.Add(this.lblGagner);
            this.panel1.Location = new System.Drawing.Point(236, 638);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(546, 126);
            this.panel1.TabIndex = 23;
            // 
            // lblScore
            // 
            this.lblScore.BackColor = System.Drawing.Color.Snow;
            this.lblScore.Font = new System.Drawing.Font("Comic Sans MS", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.Color.Maroon;
            this.lblScore.Location = new System.Drawing.Point(0, 79);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(546, 28);
            this.lblScore.TabIndex = 1;
            this.lblScore.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGagner
            // 
            this.lblGagner.BackColor = System.Drawing.Color.Snow;
            this.lblGagner.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGagner.Location = new System.Drawing.Point(0, 0);
            this.lblGagner.Name = "lblGagner";
            this.lblGagner.Size = new System.Drawing.Size(546, 69);
            this.lblGagner.TabIndex = 0;
            this.lblGagner.Text = "Mais qui gagne la manche ?";
            this.lblGagner.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // cmdQuitter_Jeu
            // 
            this.cmdQuitter_Jeu.BackColor = System.Drawing.Color.Transparent;
            this.cmdQuitter_Jeu.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdQuitter_Jeu.ForeColor = System.Drawing.Color.Red;
            this.cmdQuitter_Jeu.Location = new System.Drawing.Point(883, 717);
            this.cmdQuitter_Jeu.Name = "cmdQuitter_Jeu";
            this.cmdQuitter_Jeu.Size = new System.Drawing.Size(100, 35);
            this.cmdQuitter_Jeu.TabIndex = 22;
            this.cmdQuitter_Jeu.Text = "Quitter";
            this.cmdQuitter_Jeu.UseVisualStyleBackColor = false;
            this.cmdQuitter_Jeu.Click += new System.EventHandler(this.cmdQuitter_Jeu_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(231, 208);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(421, 26);
            this.label2.TabIndex = 21;
            this.label2.Text = " Pour jouer clique sur l\'image de ton choix";
            // 
            // lblPseudo
            // 
            this.lblPseudo.AutoSize = true;
            this.lblPseudo.BackColor = System.Drawing.Color.Transparent;
            this.lblPseudo.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPseudo.Location = new System.Drawing.Point(149, 123);
            this.lblPseudo.Name = "lblPseudo";
            this.lblPseudo.Size = new System.Drawing.Size(0, 31);
            this.lblPseudo.TabIndex = 20;
            // 
            // picImageJoueur
            // 
            this.picImageJoueur.BackColor = System.Drawing.Color.Transparent;
            this.picImageJoueur.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picImageJoueur.Location = new System.Drawing.Point(22, 96);
            this.picImageJoueur.Name = "picImageJoueur";
            this.picImageJoueur.Size = new System.Drawing.Size(94, 95);
            this.picImageJoueur.TabIndex = 19;
            this.picImageJoueur.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(350, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 41);
            this.label1.TabIndex = 18;
            this.label1.Text = "Mushi Ken c\'est parti";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // frm_Zone_Jeu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MushiKen_Kicode.Properties.Resources.fondJApon_Filigrane;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1032, 783);
            this.Controls.Add(this.panelTimer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblPseudoJeu);
            this.Controls.Add(this.picOrdinateurSerpent);
            this.Controls.Add(this.picOrdinateurLimace);
            this.Controls.Add(this.picOrdinateurGrenouille);
            this.Controls.Add(this.picJoueurSerpent);
            this.Controls.Add(this.picJoueurLimace);
            this.Controls.Add(this.picJoueurGrenouille);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cmdQuitter_Jeu);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblPseudo);
            this.Controls.Add(this.picImageJoueur);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_Zone_Jeu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gameplay";
            this.panelTimer.ResumeLayout(false);
            this.panelTimer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picOrdinateurSerpent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOrdinateurLimace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOrdinateurGrenouille)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picJoueurSerpent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picJoueurLimace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picJoueurGrenouille)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picImageJoueur)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelTimer;
        private System.Windows.Forms.Label lblTemps0;
        private System.Windows.Forms.Label lblTempsRestantTitre;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblPseudoJeu;
        private System.Windows.Forms.PictureBox picOrdinateurSerpent;
        private System.Windows.Forms.PictureBox picOrdinateurLimace;
        private System.Windows.Forms.PictureBox picOrdinateurGrenouille;
        private System.Windows.Forms.PictureBox picJoueurSerpent;
        private System.Windows.Forms.PictureBox picJoueurLimace;
        private System.Windows.Forms.PictureBox picJoueurGrenouille;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblGagner;
        private System.Windows.Forms.Button cmdQuitter_Jeu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPseudo;
        private System.Windows.Forms.PictureBox picImageJoueur;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
    }
}