﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MushiKen_Kicode
{
    public partial class frm_Zone_Jeu : Form
    {
        #region Variable

        int scoreJoueur;
        int scoreOrdinateur;
        int valueTimer;
        String RésultVictoire;
        String nameJoueur;
        Random aleatoire;
        List<PictureBox> Picture;
        Color[] couleurTimer;
        frm_FinDePartie resultatPartie;

        #endregion

        public frm_Zone_Jeu(String nomJoueur, Image imageJoueur)
        {
            InitializeComponent(); 
            initialisationVariable(nomJoueur, imageJoueur);
        }

        #region Méthodes


        /// <summary>
        /// Procédure => Initialisation des propriétes
        /// </summary>
        /// <param name="nomJoueur">Nom du joueur</param>
        /// <param name="imageJoueur">Image  sélectionné par le joueur</param>
        private void initialisationVariable(String nomJoueur, Image imageJoueur)
        {
            this.scoreJoueur = 0;
            this.scoreOrdinateur = 0;
            this.valueTimer = 30;

            this.aleatoire = new Random();

            this.nameJoueur = nomJoueur;

            this.Picture = new List<PictureBox>()
            {
              picJoueurGrenouille, picJoueurLimace, picJoueurSerpent,
              picOrdinateurGrenouille, picOrdinateurLimace, picOrdinateurSerpent
            };
            this.couleurTimer = new Color[2] { Color.White, Color.Red };

            lblPseudo.Text = nameJoueur + " c'est à toi";
            picImageJoueur.BackgroundImage = imageJoueur;
            lblPseudoJeu.Text = nameJoueur;
            this.lblScore.Text = "Score : " + this.nameJoueur + " - Ordinateur";
            timer1.Start();
        }

        /// <summary>
        /// Procédure => Temps Restant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick_1(object sender, EventArgs e)
        {
            lblTimer.Text = valueTimer.ToString();
            if (valueTimer < 10 && valueTimer > 0)
            {
                panelTimer.BackColor = couleurTimer[valueTimer % 2];
                lblTimer.Text = "0" + valueTimer.ToString();
            }
            else if (valueTimer == 0)
            {
                timer1.Stop();
                MessageBox.Show("\tLe temps est ecoulé\nVous êtes directement redirigé vers la page d'accueil", "TEMPS ÉCOULÉ");
                this.Close();
            }
            valueTimer--;
        }

        /// <summary>
        /// Procédure = Action effectué lors d'un click sur l'un des picture box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void picture_Click(object sender, EventArgs e)
        {
            initialisePicture(Picture, true);
            PictureBox button = (PictureBox)sender;
            String tagOrdinateur;
            String tagJoueur;

            button.BackColor = Color.GreenYellow;
            tagOrdinateur = clickPictureOrdinateur();
            tagJoueur = button.Tag.ToString();
            this.valueTimer = 30;

            determineResultat(tagJoueur, tagOrdinateur, out RésultVictoire);

            lblGagner.Text = affichageScore(tagJoueur, tagOrdinateur, RésultVictoire);

            lblScore.Text = "Score : " + this.nameJoueur + " (" + scoreJoueur.ToString() + ") - (" + scoreOrdinateur.ToString() + ") Ordinateur";

            ScorefinDePartie(scoreJoueur, scoreOrdinateur, RésultVictoire);
        }

        /// <summary>
        /// Procédure => Initialisation des PictureBox
        /// </summary>
        /// <param name="picture">Liste des picture box</param>
        /// <param name="enabled">Booléan permettant de savoir si le picture est enabled</param>
        private void initialisePicture(List<PictureBox> picture, bool enabled)
        {
            for (int i = 0; i < picture.Count(); i++)
            {
                picture[i].Enabled = enabled;
                picture[i].BackColor = Color.Snow;
                if (i > 2)
                {
                    picture[i].Enabled = !enabled;
                }
            }
        }

        /// <summary>
        /// Fonction => Recupère aléatoirement le tag d'un des picture box de l'ordinateur
        /// </summary>
        /// <returns>Tag du picture box cliqué</returns>
        private String clickPictureOrdinateur()
        {
            int entier = aleatoire.Next(3);
            Picture[entier + 3].BackColor = Color.Blue;

            return Picture[entier + 3].Tag.ToString();
        }

        /// <summary>
        /// Procédure => Détermine le vainquer de la manche
        /// </summary>
        /// <param name="tagJoueur">Tag du pictureBox cliqué par le joueur</param>
        /// <param name="tagOrdinateur">Tag du pictureBox cliqué par l'ordinateur</param>
        /// <param name="resultVictoire">Résultat de la manche</param>
        private void determineResultat(String tagJoueur, String tagOrdinateur, out String resultVictoire)
        {

            if (tagJoueur == tagOrdinateur)
            {
                resultVictoire = "égalité";
            }
            else if (tagJoueur == "grenouille" && tagOrdinateur == "limace")
            {
                resultVictoire = "Joueur";
                scoreJoueur += 2;
                scoreOrdinateur--;
            }
            else if (tagJoueur == "limace" && tagOrdinateur == "serpent")
            {
                resultVictoire = "Joueur";
                scoreJoueur += 2;
                scoreOrdinateur--;
            }
            else if (tagJoueur == "serpent" && tagOrdinateur == "grenouille")
            {
                resultVictoire = "Joueur";
                scoreJoueur += 2;
                scoreOrdinateur--;
            }
            else
            {
                resultVictoire = "Ordinateur";
                scoreOrdinateur += 2;
                scoreJoueur--;
            }

        }

        /// <summary>
        /// Fonction => Affichage du Score
        /// </summary>
        /// <param name="tagJoueur">Tag du pictureBox cliqué par le joueur</param>
        /// <param name="tagOrdinateur">Tag du pictureBox cliqué par l'ordinateur</param>
        /// <param name="resultVictoire">Résultat de la manche</param>
        /// <returns>String affichant l'explication</returns>
        private String affichageScore(String tagJoueur, String tagOrdinateur, String resultVictoire)
        {
            String explication;
            String marquerPoint;

            marquerPoint = this.nameJoueur + " a marqué le point";
            explication = "\n" + tagJoueur + " gagne contre " + tagOrdinateur;
            if (resultVictoire == "égalité")
            {
                marquerPoint = "Il y a égalité entre " + this.nameJoueur + " et l'Ordinateur";
                explication = "";
            }
            else if (resultVictoire == "Ordinateur")
            {
                marquerPoint = resultVictoire + " a marqué le point";
                explication = "\n" + tagOrdinateur + " gagne contre " + tagJoueur;
            }

            return marquerPoint + explication;
        }

        /// <summary>
        /// Procédure => Ouvre un fomulaire pour le vainqueur de la partie
        /// </summary>
        /// <param name="scoreJoueur">Score du joueur</param>
        /// <param name="scoreOrdinateur">Score de l'Ordinateur</param>
        /// <param name="resultatVictoire">Résultat de la manche</param>
        private void ScorefinDePartie(int scoreJoueur, int scoreOrdinateur, String resultatVictoire)
        {
            if (scoreJoueur >= 10)
            {

                timer1.Stop();
                this.Close();
                resultatPartie = new frm_FinDePartie(resultatVictoire, this.nameJoueur);
                resultatPartie.ShowDialog();
            }
            else if (scoreOrdinateur >= 10)
            {
                timer1.Stop();
                this.Close();
                resultatPartie = new frm_FinDePartie(resultatVictoire, "Ordinateur");
                resultatPartie.ShowDialog();
            }
        }

        #endregion

        #region Click

        private void cmdQuitter_Jeu_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        #endregion

    }
}
